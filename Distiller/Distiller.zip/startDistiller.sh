#!/bin/bash
# Скрипт запуска Distiller
# Запуск: bash startDistiller.sh

cd "/home/pi/Distiller"
python runserver.py
